# LugazGO — Codex Starter

Paquete maestro de migración para abrir LugazGO como proyecto de Codex.

**Estado del paquete:** estructura y contexto consolidados; activos maestros no disponibles en el proyecto de origen.  
**Fecha de la migración:** 30 de agosto de 2026.  
**Fase activa:** identidad visual básica, con alcance bloqueado.

## Visión

LugazGO ayuda a descubrir lugares con encanto, tranquilos, poco masificados y menos explotados. La marca busca despertar curiosidad por destinos con carácter sin convertir el descubrimiento en una experiencia ruidosa o genérica.

## Propósito de este repositorio

Convertir el estado válido de LugazGO en una fuente maestra de archivos y decisiones. Este paquete no traslada conversaciones completas ni hipótesis descartadas: conserva únicamente lo confirmado, registra lo pendiente y evita rellenar huecos con invenciones.

## Estado actual

Está confirmado:

- nombre: `LugazGO`;
- propósito centrado en lugares con encanto, tranquilos, poco masificados y menos explotados;
- personalidad minimalista, eco-friendly, premium, misteriosa y curiosa;
- dirección cromática suave, orgánica y pastel;
- concepto de la `O` distintiva con curvas topográficas diagonales tipo `ø` y un punto de ubicación aproximadamente central/superior derecho;
- alcance actual limitado a logo, símbolo, favicon y paleta básica.

No está disponible o no está aprobado todavía:

- ningún SVG maestro auténtico;
- valores cromáticos exactos;
- tipografía;
- geometría exacta de las curvas, el punto y el resto del logotipo;
- variantes o reglas de aplicación más amplias.

Por tanto, este paquete **no contiene un logotipo falso ni una reconstrucción especulativa**.

## Activos maestros que faltan

La estructura de migración espera estos tres SVG auténticos en `brand/logo/`:

- `lugazgo-primary.svg` — logotipo principal;
- `lugazgo-symbol.svg` — símbolo independiente;
- `favicon.svg` — favicon maestro.

No aparecieron en los archivos accesibles del proyecto de origen. Consulta `brand/logo/README.md` antes de incorporarlos.

También falta la definición exacta de la paleta: nombres de color y valores HEX/RGB, además de cualquier equivalencia adicional que se apruebe. La dirección verbal no debe convertirse automáticamente en códigos de color.

## Estructura

```text
LugazGO-Codex-Starter/
├── AGENTS.md
├── README.md
├── brand/
│   ├── logo/
│   │   └── README.md
│   ├── colors/
│   │   └── README.md
│   └── references/
│       └── README.md
├── docs/
│   ├── brand-context.md
│   ├── decisions.md
│   └── roadmap.md
├── data/
│   └── README.md
└── app/
    └── README.md
```

## Cómo empezar

1. Descomprime el ZIP y abre la carpeta `LugazGO-Codex-Starter` como proyecto en Codex.
2. Lee `AGENTS.md`, `docs/decisions.md` y `docs/brand-context.md` antes de pedir cambios.
3. Recupera los SVG maestros originales. Cópialos a `brand/logo/` sin rasterizarlos ni reinterpretarlos.
4. Si sus nombres originales son distintos, conserva los originales y registra el mapeo en `docs/decisions.md` antes de renombrar nada.
5. Documenta los valores exactos de la paleta únicamente cuando hayan sido aprobados.
6. Trabaja solo en logo, símbolo, favicon y paleta hasta que una nueva decisión desbloquee otra fase.

No ejecutes una inicialización que sobrescriba `AGENTS.md`; ya contiene las reglas específicas de LugazGO.

## Disciplina de cambios

Toda modificación futura que altere una decisión o un activo aprobado debe quedar registrada en `docs/decisions.md`. Una propuesta no modifica el estado oficial hasta recibir aprobación explícita.

