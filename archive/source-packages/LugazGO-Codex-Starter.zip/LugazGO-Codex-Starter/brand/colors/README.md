# Colores — especificación pendiente

## Dirección aprobada

La paleta de LugazGO debe ser:

- suave;
- orgánica;
- pastel.

## Datos no disponibles

No están aprobados o accesibles:

- nombres de color;
- valores HEX;
- valores RGB;
- equivalencias CMYK o Pantone;
- jerarquía entre colores;
- combinaciones y reglas de contraste.

No generes valores por aproximación. Cuando se apruebe la paleta, registra primero la decisión en `docs/decisions.md` y añade aquí una especificación versionable.

