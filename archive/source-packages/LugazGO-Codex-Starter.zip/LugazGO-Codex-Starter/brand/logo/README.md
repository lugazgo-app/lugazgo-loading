# Logo — activos pendientes

No se encontraron SVG maestros accesibles durante la migración. Faltan exactamente:

- `lugazgo-primary.svg` — logotipo principal auténtico;
- `lugazgo-symbol.svg` — símbolo auténtico;
- `favicon.svg` — favicon auténtico.

## Cómo incorporarlos

1. Recuperar los archivos originales del proyecto o de su fuente de diseño.
2. Confirmar que son SVG vectoriales auténticos, no una imagen rasterizada incrustada dentro de un SVG.
3. Copiarlos aquí sin alterar trazados, proporciones, colores ni metadatos relevantes.
4. Si los nombres originales difieren, conservarlos hasta registrar el nombre definitivo o el mapeo en `docs/decisions.md`.
5. Registrar la procedencia y la incorporación en `docs/decisions.md`.

No crear sustitutos falsos, reconstrucciones aproximadas ni archivos vacíos con extensión `.svg`.

