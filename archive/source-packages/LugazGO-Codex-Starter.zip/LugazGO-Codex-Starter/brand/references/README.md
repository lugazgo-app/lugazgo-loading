# Referencias de marca

No había referencias visuales accesibles en el material de migración.

Usa esta carpeta únicamente para fuentes identificadas y pertinentes. Cada referencia futura debe indicar su procedencia y si sirve como contexto, inspiración o fuente autorizada. Una referencia no equivale a una decisión aprobada y nunca debe sustituir a un SVG maestro.

